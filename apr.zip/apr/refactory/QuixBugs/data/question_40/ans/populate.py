from sys import stdin
fname = input('function: ')
lines = [inp[:len(inp)-1] for inp in stdin.readlines()]

for i, line in enumerate(lines):
    i += 1
    inps, out = eval(line)
    inps = [str(inp) for inp in inps]
    out = str(out)
    with open(f'input_00{i}.txt', 'a') as f:
        f.write(f'{fname}({", ".join(inps)})')
    with open(f'output_00{i}.txt', 'a') as f:
        f.write(out)
