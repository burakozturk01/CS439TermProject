import shutil

source_file = './question_1/ans/populate.py'
target_directories = [f'./question_{i}/ans/' for i in range(2, 41)]

for directory in target_directories:
    shutil.copy(source_file, directory)