import shutil
# copy the contents of "question_example" folder to all other folders
for i in range(7, 51):
    shutil.copytree("question_example", f"question_{i}")
