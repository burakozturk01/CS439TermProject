import os

folders = ['correct_python_programs', 'python_programs', 'json_testcases', 'python_testcases']
lists = [[] for _ in folders]

tuples = []

# read every file's name in a directory
for i, list in enumerate(lists):
    for root, dirs, files in os.walk(folders[i] + '/'):
        for file in files:
            if file.endswith('.py') or file.endswith('.json'):
                list.append(os.path.join(root, file).split('/')[1].split('.')[0].replace("_", " "))

for name in lists[0]:
    if name in lists[2] and "test " + name in lists[3]:
        tuples.append((name.ljust(32), name.ljust(32), name.ljust(32), ("test " + name).ljust(32)))
    elif name in lists[2]:
        tuples.append((name.ljust(32), name.ljust(32), name.ljust(32), "".ljust(32)))
    elif "test " + name in lists[3]:
        tuples.append((name.ljust(32), name.ljust(32), "".ljust(32), ("test " + name).ljust(32)))
    else:
        tuples.append((name.ljust(32), name.ljust(32), "".ljust(32), "".ljust(32)))

tuples.sort(key=lambda x: ('zz' if " test" in x[0] else "") + x[0])

print(f"{'Correct Python Programs'.ljust(32)} | {'Python Programs'.ljust(32)} | {'JSON Testcases'.ljust(32)} | {'Python Testcases'.ljust(32)}")
print("-".ljust(32, "-") + ((" | " + "-".ljust(32, "-")) * (len(folders)-1)))
for e in tuples:
    print(*e, sep=' | ')


