#!/bin/bash

source venv/bin/activate

# Directory containing the data
DATA_DIR="./quix_data"

# Loop through all 40 questions
for i in {1..40}; do
  # Define the question identifier
  QUESTION="question_$i"

  # Define the output file path
  OUTPUT_FILE="$DATA_DIR/$QUESTION/output.txt"

  # Run the command and redirect output to the file
  time python3 run.py -d "$DATA_DIR" -q "$QUESTION" -s 0 -o -m -b -c > $OUTPUT_FILE

  # Optionally, print a message to indicate progress
  echo "Processed $QUESTION, output saved to $OUTPUT_FILE"
done

