import re
from collections import defaultdict

def parse_file(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()

    metric_times = defaultdict(float)

    metric_pattern = re.compile(r'\|\s+(\w+)\s+\|\s+([\d\.]+)\s+\|')

    for line in lines:
        line = line.strip()
        match = metric_pattern.match(line)
        if match:
            metric, value = match.groups()
            if metric in ['time', 'ol_refactoring_time', 'gcr_time', 'mut_time', 'vn_map_time', 'spec_syn_time', 'syn_time', 'rps']:
                metric_times[metric] += float(value)
    
    return metric_times

if __name__ == "__main__":
    #patch_counts = {"success_wo_mut": 0, "success_w_mut": 0, "fail_other": 0, "fail_exception": 0}

    filename = [f'./question_{i}/output.txt' for i in range(1, 41)]
    metriclist = []
    for i in range(0, len(filename)):
        """with open(filename[i], 'r') as file:
            text = file.read()
            patch_counts["success_wo_mut"] += text.count("success_wo_mut")
            patch_counts["success_w_mut"] += text.count("success_w_mut")
            patch_counts["fail_other"] += text.count("fail_other")
            patch_counts["fail_exception"] += text.count("fail_exception")"""
        metrics = {}
        metric_times = parse_file(filename[i])
        print(f"\nFile: {filename[i]}")
        for metric, total_time in metric_times.items():
            print(f"{metric}: {total_time:.3f}")
            metrics[metric] = total_time
        metriclist.append(metrics)
    
    # sum all metrics
    sum_metrics = defaultdict(float)
    for metrics in metriclist:
        for metric, value in metrics.items():
            sum_metrics[metric] += value
    print("\nSum of all metrics:")
    for metric, total_time in sum_metrics.items():
        print(f"{metric}: {total_time:.3f}")

    #print("\nPatch counts:")
    #for patch_type, count in patch_counts.items():
    #    print(f"{patch_type}: {count}")
        