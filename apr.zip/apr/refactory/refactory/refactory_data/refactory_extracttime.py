import re
from collections import defaultdict

def parse_file(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()

    metric_times = defaultdict(float)

    metric_pattern = re.compile(r'\|\s+(\w+)\s+\|\s+([\d\.]+)\s+\|')

    for line in lines:
        line = line.strip()
        match = metric_pattern.match(line)
        if match:
            metric, value = match.groups()
            if metric in ['ol_refactoring_time', 'gcr_time', 'mut_time', 'vn_map_time', 'spec_syn_time', 'syn_time', 'rps']:
                metric_times[metric] += float(value)
    
    return metric_times

if __name__ == "__main__":
    filename = ['./q1out.txt', './q2out.txt', './q3out.txt', './q4out.txt', './q5out.txt']
    for i in range(0, len(filename)):
        metric_times = parse_file(filename[i])
        print(f"\nFile: {filename[i]}")
        for metric, total_time in metric_times.items():
            print(f"{metric}: {total_time:.3f}")
        
